var express = require("express");
const { ethers } = require("ethers");
var Web3EthAccounts = require('web3-eth-accounts');
var app = express();

const config_json = require('config');

app.listen(3000, () => {
 console.log("Server running on port 3000");
});

app.get("/document/announce", async (req, res, next) => {

    document_hash = req.query.hash;

    // we get some config
    config = config_json.get('general');
    account = config_json.get('account');
    credentials = config_json.get('credetials');

    // set some transaction parameters
    current_ts = Math.floor(Date.now()/1000);
    delegee = account.mdi_user_address;
    data = "0x0000000000000000000000000000000000000000000000000000000000000000";
    note = "";

    // build the transaction data
    var transaction = {
      action: 'announce',
      expirationTimestamp: current_ts+5*60,
      maxFee: "" + ethers.utils.parseEther("10"),
      delegee: delegee,
      document: {
        hash: document_hash,
        data: data,
        note: note
      }
    };

    // sign the transaction
    var signature = await signTransaction(config, account, transaction);

    // pack transaction data into mdi message
    var mdi_message = {
        'sequence': "" + current_ts,
        'mtx':  transaction
    }
    mdi_message.mtx.signature = signature;
    mdi_message.mtx.signer = account.address;

    // configure mqtt client
    const mqtt = require('mqtt')
    var finished = 0;
    mqtt_options={
        username: credentials.mdi_user,
        password: credentials.mdi_password,
        clean:true
    };

    console.log("Connecting to MDI message broker: " + account.mdi_url);
    const client  = mqtt.connect(account.mdi_url, mqtt_options);

    // when connected we subscribe to the topic "mdi/v1/cl/{mdi_user_address}"
    // to get the transaction result, and than send the mdi message
    client.on('connect', function () {
        console.log("... connected, subscribing for any reply ...");
        client.subscribe('mdi/v1/cl/' + account.mdi_user_address, function (err) {      
            if (!err) {
                console.log("... subscribed, sending message ...");
                client.publish('mdi/v1/op/' + account.mdi_user_address, JSON.stringify(mdi_message))
            }
        })
    })

    // we log the transaction result when received
    client.on('message', async function (topic, message) {
        response = JSON.parse(message.toString())
        console.log("... mdi server response: " + JSON.stringify(response));
        client.end()    
        finished = 1
    })

    // we wait for the transaction response to come back and send result to client
    while (! finished) await new Promise(resolve => setTimeout(resolve, 100));
    res.json(response);
});


async function signTransaction(config, account, transaction) {

    const domain = {
      name: 'OYB Notarization dApp',
      version: '1.1.1',
      chainId: config.chain_id,
      verifyingContract: config.contract_address,
    };

    const types = {
        Document: [
              { name: "hash", type: "bytes32" },
              { name: "data", type: "bytes32" },
              { name: "note", type: "string" },
        ],

        Transaction: [
            { name: "action", type: "string" },
            { name: "expirationTimestamp", type: "uint256" },
            { name: "maxFee", type: "uint256" },
            { name: "delegee", type: "address" },
            { name: "document", type: "Document" },
        ]
    }

    console.log("Signing transaction:\n" + JSON.stringify(transaction, null, 4) + 
        "\nwith domain:\n" + JSON.stringify(domain, null, 4) + 
        "\nand type:\n" + JSON.stringify(types, null, 4) + ".");

    var wallet = new ethers.Wallet(account.private_key);
    return await wallet._signTypedData(domain, types, transaction);
}
